package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Obsidian Berry Canvas & Surface (#ae275f theme)
val CanvasDark = Color(0xFF0F080E)
val CanvasDarkSubtle = Color(0xFF160D15)
val CanvasCard = Color(0xFF1C111A)
val CanvasCardElevated = Color(0xFF261623)
val CanvasInput = Color(0xFF170E16)
val CardBorder = Color(0xFF3B1E30)
val CardBorderHighlight = Color(0xFF5A2A47)
val CardBorderGlow = Color(0xFFAE275F)

// Brand & Accent Colors - #ae275f (Crimson / Magenta Rose)
val PrimaryIndigo = Color(0xFFAE275F)
val PrimaryIndigoDark = Color(0xFF861B46)
val PrimaryIndigoLight = Color(0xFFD4447E)
val AccentCyan = Color(0xFFE24B88)
val AccentCyanLight = Color(0xFFF9A8D4)
val AccentEmerald = Color(0xFF10B981)
val AccentEmeraldDark = Color(0xFF059669)
val AccentEmeraldBg = Color(0xFF064E3B)
val AccentAmber = Color(0xFFF59E0B)
val AccentAmberDark = Color(0xFFD97706)
val AccentAmberBg = Color(0xFF451A03)
val AccentRose = Color(0xFFF43F5E)
val AccentRoseDark = Color(0xFFE11D48)
val AccentRoseBg = Color(0xFF4C0519)
val AccentPurple = Color(0xFFAE275F)

// Typography & Neutrals
val TextPrimary = Color(0xFFFDF2F8)
val TextSecondary = Color(0xFFE2D1DD)
val TextMuted = Color(0xFFA88E9F)
val TextTertiary = Color(0xFF7A6473)

// Glassmorphism Accents
val GlassWhite08 = Color(0x14FFFFFF)
val GlassWhite12 = Color(0x1FFFFFFF)
val GlassWhite04 = Color(0x0AFFFFFF)

// Legacy alias compatibility for seamless references
val DarkTealBackground = CanvasDark
val DarkTealCard = CanvasCard
val DarkTealInput = CanvasInput
val DarkTealBorder = CardBorder
val AccentOrange = AccentAmber
val AccentOrangeDark = AccentAmberDark
val AccentBlueIcon = PrimaryIndigo
val TextWhite = TextPrimary
val TextTealLight = AccentCyanLight
val StatusGreen = AccentEmerald
val StatusPending = AccentAmber
val StatusResolved = AccentCyan

// Gradient Brushes
val BrandGradientBrush = Brush.horizontalGradient(
    listOf(PrimaryIndigo, AccentCyan)
)

val CardGlowBrush = Brush.linearGradient(
    listOf(Color(0xFF3B1E30), Color(0xFF170E16))
)

val SuccessGradientBrush = Brush.horizontalGradient(
    listOf(Color(0xFF059669), Color(0xFF10B981))
)

val AmberGradientBrush = Brush.horizontalGradient(
    listOf(Color(0xFFD97706), Color(0xFFF59E0B))
)

