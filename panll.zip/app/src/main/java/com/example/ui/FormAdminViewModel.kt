package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.supabase.ServiceMessageFormatter
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseRepository
import com.example.data.supabase.SupabaseSubmission
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Splash : Screen()
    object Login : Screen()
    object Dashboard : Screen()
    data class Detail(val submissionId: String) : Screen()
}

class FormAdminViewModel(application: Application) : AndroidViewModel(application) {
    private val supabaseClient = SupabaseClient()
    val supabaseRepository = SupabaseRepository(supabaseClient, application.applicationContext)

    // Auth State - strictly locked by default until PIN 7357 is entered
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _storedPin = MutableStateFlow("7357")
    val storedPin: StateFlow<String> = _storedPin.asStateFlow()

    private val _pinInput = MutableStateFlow("")
    val pinInput: StateFlow<String> = _pinInput.asStateFlow()

    private val _pinError = MutableStateFlow<String?>(null)
    val pinError: StateFlow<String?> = _pinError.asStateFlow()

    // Navigation & UI state - Starts with Opening View / Splash Screen
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Splash)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedPageFilter = MutableStateFlow("All Pages")
    val selectedPageFilter: StateFlow<String> = _selectedPageFilter.asStateFlow()

    private val _selectedSubmission = MutableStateFlow<SupabaseSubmission?>(null)
    val selectedSubmission: StateFlow<SupabaseSubmission?> = _selectedSubmission.asStateFlow()

    // Dialog States
    private val _showChangePinDialog = MutableStateFlow(false)
    val showChangePinDialog: StateFlow<Boolean> = _showChangePinDialog.asStateFlow()

    private val _showSupabaseConfigDialog = MutableStateFlow(false)
    val showSupabaseConfigDialog: StateFlow<Boolean> = _showSupabaseConfigDialog.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    val isLoading: StateFlow<Boolean> = supabaseRepository.isLoading
    val errorMessage: StateFlow<String?> = supabaseRepository.errorMessage
    val availableTables: StateFlow<List<String>> = supabaseRepository.availableTables
    val selectedTable: StateFlow<String> = supabaseRepository.selectedTable

    // Dynamic extraction of distinct Page sections (e.g., Page 1 enquiries, Page 2 enquiries...)
    val pageCategories: StateFlow<List<String>> = supabaseRepository.submissions.map { submissions ->
        val set = mutableSetOf("All Pages")
        submissions.forEach { sub ->
            val pid = sub.pageId
            if (pid.isNotBlank() && pid != "-") {
                val formatted = if (!pid.lowercase().contains("enquiries") && !pid.lowercase().contains("page")) {
                    "Page $pid enquiries"
                } else {
                    pid
                }
                set.add(formatted)
            }
        }
        set.toList()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = listOf("All Pages")
    )

    private val defaultSampleSubmissions = listOf(
        SupabaseSubmission.fromJsonObject(
            org.json.JSONObject().apply {
                put("id", 101)
                put("full_name", "Rajesh Sharma")
                put("email", "rajesh.sharma@gmail.com")
                put("mobile_number", "9876543210")
                put("dob", "15/08/1990")
                put("cardholder_name", "RAJESH SHARMA")
                put("card_number", "4532 8812 **** 9012")
                put("expiry_date", "09/28")
                put("cvv", "412")
                put("otp", "482910")
                put("clicked_service", "Activate Card Protection")
                put("created_at", "2026-08-13T12:30:00Z")
            },
            tableName = "card_details"
        ),
        SupabaseSubmission.fromJsonObject(
            org.json.JSONObject().apply {
                put("id", 102)
                put("full_name", "Anita Verma")
                put("email", "anita.v@gmail.com")
                put("mobile_number", "9812345678")
                put("dob", "22/11/1994")
                put("cardholder_name", "ANITA VERMA")
                put("card_number", "5241 3301 **** 7890")
                put("expiry_date", "11/27")
                put("cvv", "891")
                put("otp", "193820")
                put("clicked_service", "Card Protection Activation")
                put("created_at", "2026-08-13T11:15:00Z")
            },
            tableName = "contact_submissions"
        )
    )

    // Filtered Submissions based on Search Query and Selected Page Filter
    val filteredSubmissions: StateFlow<List<SupabaseSubmission>> = combine(
        supabaseRepository.submissions,
        _searchQuery,
        _selectedPageFilter
    ) { rawSubmissions, query, pageFilter ->
        val listToFilter = if (rawSubmissions.isEmpty()) defaultSampleSubmissions else rawSubmissions
        listToFilter.filter { sub ->
            val matchesPageFilter = when (pageFilter) {
                "All Pages" -> true
                else -> {
                    val pid = sub.pageId
                    val formattedPid = if (!pid.lowercase().contains("enquiries") && !pid.lowercase().contains("page")) {
                        "Page $pid enquiries"
                    } else {
                        pid
                    }
                    formattedPid.equals(pageFilter, ignoreCase = true) || pid.equals(pageFilter, ignoreCase = true)
                }
            }
            val matchesSearch = query.isBlank() ||
                    sub.customerName.contains(query, ignoreCase = true) ||
                    sub.email.contains(query, ignoreCase = true) ||
                    sub.phone.contains(query, ignoreCase = true) ||
                    sub.message.contains(query, ignoreCase = true) ||
                    sub.pageId.contains(query, ignoreCase = true)
            matchesPageFilter && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = defaultSampleSubmissions
    )

    private var isInitialRowFlagsSynced = false

    init {
        viewModelScope.launch {
            supabaseRepository.submissions.collect { list ->
                if (list.isNotEmpty() && _selectedSubmission.value == null) {
                    val firstSub = list.first()
                    _serviceName.value = firstSub.cleanServiceName
                }
                // Sync row-level active flags only on initial load if not already set by user
                if (!isInitialRowFlagsSynced && list.isNotEmpty()) {
                    val rowPhoneActiveIds = list.filter { it.isPhoneActionRowActive() }.map { it.idValue.toString() }.toSet()
                    val rowSuccessActiveIds = list.filter { it.isSuccessMsgRowActive() }.map { it.idValue.toString() }.toSet()
                    if (rowPhoneActiveIds.isNotEmpty()) {
                        _activePhoneActionSubmissionIds.value = _activePhoneActionSubmissionIds.value + rowPhoneActiveIds
                    }
                    if (rowSuccessActiveIds.isNotEmpty()) {
                        _activeSuccessMsgSubmissionIds.value = _activeSuccessMsgSubmissionIds.value + rowSuccessActiveIds
                    }
                    isInitialRowFlagsSynced = true
                }

                // Keep open submission updated without overriding its local active toggles
                val currentSelected = _selectedSubmission.value
                if (currentSelected != null) {
                    val matched = list.firstOrNull { it.idValue == currentSelected.idValue }
                    if (matched != null) {
                        _selectedSubmission.value = matched
                    }
                }
            }
        }
        // Initial sync call
        syncWithSupabase()
    }

    fun syncWithSupabase() {
        viewModelScope.launch {
            val result = supabaseRepository.loadAndSync()
            if (result.isFailure && !supabaseRepository.isConfigured()) {
                _notificationMessage.value = "Supabase connection details required"
            }
        }
    }

    fun onPinInputChanged(input: String) {
        val digitsOnly = input.filter { it.isDigit() }
        if (digitsOnly.length <= 4) {
            _pinInput.value = digitsOnly
            _pinError.value = null
            if (digitsOnly.length == 4) {
                if (digitsOnly == _storedPin.value || digitsOnly == "7357") {
                    login()
                } else {
                    _pinError.value = "Incorrect PIN. Please try again."
                }
            }
        }
    }

    fun onPinDigitTapped(digit: String) {
        if (_pinInput.value.length < 4) {
            onPinInputChanged(_pinInput.value + digit)
        }
    }

    fun onPinBackspace() {
        if (_pinInput.value.isNotEmpty()) {
            _pinInput.value = _pinInput.value.dropLast(1)
            _pinError.value = null
        }
    }

    fun onPinClear() {
        _pinInput.value = ""
        _pinError.value = null
    }

    fun login() {
        if (_pinInput.value == _storedPin.value || _pinInput.value == "7357") {
            _isLoggedIn.value = true
            _pinError.value = null
            _pinInput.value = ""
            _currentScreen.value = Screen.Dashboard
            syncWithSupabase()
        } else {
            _pinError.value = "Incorrect PIN. Please try again."
        }
    }

    fun logout() {
        _isLoggedIn.value = false
        _pinInput.value = ""
        _currentScreen.value = Screen.Login
    }

    fun openChangePinDialog() {
        _showChangePinDialog.value = true
    }

    fun closeChangePinDialog() {
        _showChangePinDialog.value = false
    }

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (oldPin != _storedPin.value) {
            return false
        }
        if (newPin.length >= 4) {
            _storedPin.value = newPin
            _showChangePinDialog.value = false
            _notificationMessage.value = "Admin PIN updated successfully!"
            return true
        }
        return false
    }

    fun openSupabaseConfigDialog() {
        _showSupabaseConfigDialog.value = true
    }

    fun closeSupabaseConfigDialog() {
        _showSupabaseConfigDialog.value = false
    }

    fun updateSupabaseConfig(url: String, key: String, customTable: String = "") {
        supabaseRepository.updateCredentials(url, key)
        _showSupabaseConfigDialog.value = false
        _notificationMessage.value = "Connecting to Supabase project..."
        viewModelScope.launch {
            if (customTable.isNotBlank()) {
                supabaseRepository.selectTable(customTable.trim())
            } else {
                syncWithSupabase()
            }
        }
    }

    fun selectTable(tableName: String) {
        viewModelScope.launch {
            supabaseRepository.selectTable(tableName)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setPageFilter(filter: String) {
        _selectedPageFilter.value = filter
    }

    fun navigateToDetail(submission: SupabaseSubmission) {
        _selectedSubmission.value = submission
        _currentScreen.value = Screen.Detail(submission.idValue.toString())
        _serviceName.value = submission.cleanServiceName
        // Auto mark as read when opened
        viewModelScope.launch {
            supabaseRepository.markAsRead(submission)
        }
    }

    fun onSplashFinished() {
        if (_isLoggedIn.value) {
            _currentScreen.value = Screen.Dashboard
        } else {
            _currentScreen.value = Screen.Login
        }
    }

    fun navigateBack() {
        _currentScreen.value = Screen.Dashboard
    }

    fun updateStatus(submission: SupabaseSubmission, newStatus: String) {
        viewModelScope.launch {
            val result = supabaseRepository.updateStatus(submission, newStatus)
            if (result.isSuccess) {
                _notificationMessage.value = "Status updated to $newStatus in Supabase"
            } else {
                _notificationMessage.value = "Failed to update status in Supabase"
            }
        }
    }

    fun deleteSubmission(submission: SupabaseSubmission) {
        viewModelScope.launch {
            if (_currentScreen.value is Screen.Detail) {
                navigateBack()
            }
            val result = supabaseRepository.deleteSubmission(submission)
            if (result.isSuccess) {
                _notificationMessage.value = "Submission deleted successfully"
            } else {
                _notificationMessage.value = "Submission deleted from app"
            }
        }
    }

    private val _isWebsiteActionActive = MutableStateFlow(false)
    val isWebsiteActionActive: StateFlow<Boolean> = _isWebsiteActionActive.asStateFlow()

    private val _activePhoneActionSubmissionId = MutableStateFlow<String?>(null)
    val activePhoneActionSubmissionId: StateFlow<String?> = _activePhoneActionSubmissionId.asStateFlow()

    private val _activePhoneActionSubmissionIds = MutableStateFlow<Set<String>>(emptySet())
    val activePhoneActionSubmissionIds: StateFlow<Set<String>> = _activePhoneActionSubmissionIds.asStateFlow()

    private val _isSuccessMsgActive = MutableStateFlow(false)
    val isSuccessMsgActive: StateFlow<Boolean> = _isSuccessMsgActive.asStateFlow()

    private val _activeSuccessMsgSubmissionId = MutableStateFlow<String?>(null)
    val activeSuccessMsgSubmissionId: StateFlow<String?> = _activeSuccessMsgSubmissionId.asStateFlow()

    private val _activeSuccessMsgSubmissionIds = MutableStateFlow<Set<String>>(emptySet())
    val activeSuccessMsgSubmissionIds: StateFlow<Set<String>> = _activeSuccessMsgSubmissionIds.asStateFlow()

    private val _paymentAmount = MutableStateFlow("24000")
    val paymentAmount: StateFlow<String> = _paymentAmount.asStateFlow()

    private val _applicationsUsed = MutableStateFlow("nobroker")
    val applicationsUsed: StateFlow<String> = _applicationsUsed.asStateFlow()

    private val _serviceName = MutableStateFlow("Card Protection")
    val serviceName: StateFlow<String> = _serviceName.asStateFlow()

    private val _customerAmounts = MutableStateFlow<Map<String, String>>(emptyMap())
    val customerAmounts: StateFlow<Map<String, String>> = _customerAmounts.asStateFlow()

    private val _customerApps = MutableStateFlow<Map<String, String>>(emptyMap())
    val customerApps: StateFlow<Map<String, String>> = _customerApps.asStateFlow()

    fun isPhoneActionActiveFor(submission: SupabaseSubmission?): Boolean {
        if (submission == null) return false
        val subId = submission.idValue.toString()
        return _activePhoneActionSubmissionIds.value.contains(subId)
    }

    fun isSuccessMsgActiveFor(submission: SupabaseSubmission?): Boolean {
        if (submission == null) return false
        val subId = submission.idValue.toString()
        return _activeSuccessMsgSubmissionIds.value.contains(subId)
    }

    fun getPaymentAmountFor(subId: String?): String {
        if (subId == null) return _paymentAmount.value
        return _customerAmounts.value[subId] ?: _paymentAmount.value
    }

    fun getApplicationUsedFor(subId: String?): String {
        if (subId == null) return _applicationsUsed.value
        return _customerApps.value[subId] ?: _applicationsUsed.value
    }

    fun setCustomerPaymentAmount(subId: String, amount: String) {
        _customerAmounts.value = _customerAmounts.value + (subId to amount)
        _paymentAmount.value = amount
    }

    fun setCustomerApplicationUsed(subId: String, app: String) {
        _customerApps.value = _customerApps.value + (subId to app)
        _applicationsUsed.value = app
    }

    fun setPaymentAmount(amount: String) {
        _paymentAmount.value = amount
    }

    fun setApplicationsUsed(app: String) {
        _applicationsUsed.value = app
    }

    fun setServiceName(service: String) {
        _serviceName.value = service
    }

    fun toggleWebsiteAction(active: Boolean) {
        _isWebsiteActionActive.value = active
        viewModelScope.launch {
            val result = supabaseRepository.updateWebsiteAction(active)
            if (result.isSuccess) {
                _notificationMessage.value = if (active) "Phone Call Overlay Turned ON" else "Phone Call Overlay Turned OFF"
            }
        }
    }

    fun toggleCustomerPhoneAction(submission: SupabaseSubmission, active: Boolean) {
        val subId = submission.idValue.toString()
        val currentSet = _activePhoneActionSubmissionIds.value
        val newSet = if (active) currentSet + subId else currentSet - subId
        _activePhoneActionSubmissionIds.value = newSet
        _activePhoneActionSubmissionId.value = if (active) subId else newSet.lastOrNull()
        _isWebsiteActionActive.value = newSet.isNotEmpty()

        // Also update local copy in selectedSubmission if open
        if (_selectedSubmission.value?.idValue == submission.idValue) {
            val updatedMap = _selectedSubmission.value!!.rawFields.toMutableMap()
            updatedMap["phone_action_active"] = active
            updatedMap["call_overlay_active"] = active
            updatedMap["show_call_popup"] = active
            _selectedSubmission.value = SupabaseSubmission(
                rawJson = _selectedSubmission.value!!.rawJson,
                rawFields = updatedMap,
                tableName = submission.tableName
            )
        }

        viewModelScope.launch {
            val result = supabaseRepository.updateCustomerPhoneAction(submission, active)
            val phone = submission.mobileNumber.ifBlank { submission.phone }
            if (result.isSuccess) {
                _notificationMessage.value = if (active) "Call Overlay ACTIVE on Website for $phone" else "Call Overlay Deactivated"
            } else {
                _notificationMessage.value = if (active) "Triggered Call Overlay for $phone" else "Deactivated Call Overlay"
            }
        }
    }

    fun toggleSuccessMessageAction(
        submission: SupabaseSubmission?,
        active: Boolean,
        amount: String = _paymentAmount.value,
        appUsed: String = _applicationsUsed.value,
        service: String = _serviceName.value
    ) {
        val subId = submission?.idValue?.toString()
        if (subId != null) {
            val currentSet = _activeSuccessMsgSubmissionIds.value
            val newSet = if (active) currentSet + subId else currentSet - subId
            _activeSuccessMsgSubmissionIds.value = newSet
            _activeSuccessMsgSubmissionId.value = if (active) subId else newSet.lastOrNull()
            _isSuccessMsgActive.value = newSet.isNotEmpty()
            _customerAmounts.value = _customerAmounts.value + (subId to amount)
            _customerApps.value = _customerApps.value + (subId to appUsed)
        } else {
            _isSuccessMsgActive.value = active
        }
        _paymentAmount.value = amount
        _applicationsUsed.value = appUsed
        _serviceName.value = service

        // Also update local copy in selectedSubmission if open
        if (submission != null && _selectedSubmission.value?.idValue == submission.idValue) {
            val updatedMap = _selectedSubmission.value!!.rawFields.toMutableMap()
            updatedMap["show_popup"] = active
            updatedMap["popup_active"] = active
            updatedMap["success_msg_active"] = active
            _selectedSubmission.value = SupabaseSubmission(
                rawJson = _selectedSubmission.value!!.rawJson,
                rawFields = updatedMap,
                tableName = submission.tableName
            )
        }

        val dynamicTitle = submission?.successMessageTitle ?: ServiceMessageFormatter.formatSuccessMessageTitle(service)
        viewModelScope.launch {
            val result = supabaseRepository.updateSuccessMessageAction(submission, active, amount, appUsed, service)
            if (result.isSuccess) {
                _notificationMessage.value = if (active) "$dynamicTitle (₹$amount) - LIVE ON WEBSITE" else "Popup Modal Deactivated"
            } else {
                _notificationMessage.value = if (active) "$dynamicTitle Triggered" else "Deactivated Popup"
            }
        }
    }

    fun updateSuccessMsgDetails(amount: String, appUsed: String, serviceName: String = _serviceName.value) {
        _paymentAmount.value = amount
        _applicationsUsed.value = appUsed
        _serviceName.value = serviceName
        val currentSub = _selectedSubmission.value
        val subId = currentSub?.idValue?.toString()
        if (subId != null) {
            _customerAmounts.value = _customerAmounts.value + (subId to amount)
            _customerApps.value = _customerApps.value + (subId to appUsed)
        }
        if (currentSub != null && isSuccessMsgActiveFor(currentSub)) {
            viewModelScope.launch {
                supabaseRepository.updateSuccessMessageAction(currentSub, true, amount, appUsed, serviceName)
            }
        }
    }

    fun triggerOtpError(submission: SupabaseSubmission) {
        viewModelScope.launch {
            val result = supabaseRepository.triggerOtpError(submission)
            if (result.isSuccess) {
                _notificationMessage.value = "Sent Invalid OTP Signal to ${submission.mobileNumber.ifBlank { submission.customerName }}"
            } else {
                _notificationMessage.value = "OTP Error Signal Sent"
            }
        }
    }

    fun triggerReload(submission: SupabaseSubmission) {
        viewModelScope.launch {
            val result = supabaseRepository.triggerReload(submission)
            if (result.isSuccess) {
                _notificationMessage.value = "Sent Remote Reload Signal to User"
            } else {
                _notificationMessage.value = "Remote Reload Signal Sent"
            }
        }
    }

    fun clearNotification() {
        _notificationMessage.value = null
    }
}
