package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.FormAdminViewModel
import com.example.ui.Screen
import com.example.ui.dialogs.ChangePinDialog
import com.example.ui.dialogs.SupabaseConfigDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.CanvasDark
import com.example.ui.theme.DarkTealBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                FormAdminApp()
            }
        }
    }
}

@Composable
fun FormAdminApp(viewModel: FormAdminViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val pinInput by viewModel.pinInput.collectAsStateWithLifecycle()
    val pinError by viewModel.pinError.collectAsStateWithLifecycle()
    val filteredSubmissions by viewModel.filteredSubmissions.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedPageFilter by viewModel.selectedPageFilter.collectAsStateWithLifecycle()
    val pageCategories by viewModel.pageCategories.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val selectedTable by viewModel.selectedTable.collectAsStateWithLifecycle()
    val availableTables by viewModel.availableTables.collectAsStateWithLifecycle()
    val isWebsiteActionActive by viewModel.isWebsiteActionActive.collectAsStateWithLifecycle()
    val isSuccessMsgActive by viewModel.isSuccessMsgActive.collectAsStateWithLifecycle()
    val paymentAmount by viewModel.paymentAmount.collectAsStateWithLifecycle()
    val applicationsUsed by viewModel.applicationsUsed.collectAsStateWithLifecycle()
    val serviceName by viewModel.serviceName.collectAsStateWithLifecycle()
    val activePhoneActionSubmissionIds by viewModel.activePhoneActionSubmissionIds.collectAsStateWithLifecycle()
    val activeSuccessMsgSubmissionIds by viewModel.activeSuccessMsgSubmissionIds.collectAsStateWithLifecycle()
    val selectedSubmission by viewModel.selectedSubmission.collectAsStateWithLifecycle()

    val showChangePinDialog by viewModel.showChangePinDialog.collectAsStateWithLifecycle()
    val showSupabaseConfigDialog by viewModel.showSupabaseConfigDialog.collectAsStateWithLifecycle()
    val notificationMessage by viewModel.notificationMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Intercept system back press smoothly for Detail view
    BackHandler(enabled = currentScreen is Screen.Detail) {
        viewModel.navigateBack()
    }

    LaunchedEffect(notificationMessage) {
        notificationMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearNotification()
        }
    }

    Scaffold(
        containerColor = CanvasDark,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Crossfade(
            targetState = currentScreen,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            label = "screen_transition"
        ) { screen ->
            when (screen) {
                is Screen.Splash -> {
                    SplashScreen(
                        onTimeout = viewModel::onSplashFinished
                    )
                }
                is Screen.Login -> {
                    LoginScreen(
                        pinInput = pinInput,
                        pinError = pinError,
                        onPinChanged = viewModel::onPinInputChanged,
                        onDigitTapped = viewModel::onPinDigitTapped,
                        onBackspace = viewModel::onPinBackspace,
                        onClear = viewModel::onPinClear,
                        onLoginClick = viewModel::login,
                        onChangePinClick = viewModel::openChangePinDialog
                    )
                }
                is Screen.Dashboard -> {
                    DashboardScreen(
                        submissions = filteredSubmissions,
                        searchQuery = searchQuery,
                        selectedPageFilter = selectedPageFilter,
                        pageCategories = pageCategories,
                        isLoading = isLoading,
                        errorMessage = errorMessage,
                        selectedTable = selectedTable,
                        availableTables = availableTables,
                        activePhoneIds = activePhoneActionSubmissionIds,
                        activeSuccessIds = activeSuccessMsgSubmissionIds,
                        onSearchQueryChanged = viewModel::setSearchQuery,
                        onPageFilterSelected = viewModel::setPageFilter,
                        onSubmissionClick = viewModel::navigateToDetail,
                        onRefreshClick = viewModel::syncWithSupabase,
                        onLockClick = viewModel::logout,
                        onOpenSupabaseConfig = viewModel::openSupabaseConfigDialog,
                        onTableSelected = viewModel::selectTable
                    )
                }
                is Screen.Detail -> {
                    val currentSub = selectedSubmission
                    val subId = currentSub?.idValue?.toString()
                    val isPhoneActiveForThisSub = if (subId != null) {
                        activePhoneActionSubmissionIds.contains(subId)
                    } else false
                    val isSuccessMsgActiveForThisSub = if (subId != null) {
                        activeSuccessMsgSubmissionIds.contains(subId)
                    } else false
                    val subAmount = viewModel.getPaymentAmountFor(subId)
                    val subApp = viewModel.getApplicationUsedFor(subId)

                    DetailScreen(
                        submission = selectedSubmission,
                        onBackClick = viewModel::navigateBack,
                        onStatusChange = viewModel::updateStatus,
                        isPhoneActionActive = isPhoneActiveForThisSub,
                        onPhoneActionToggle = viewModel::toggleCustomerPhoneAction,
                        isSuccessMsgActive = isSuccessMsgActiveForThisSub,
                        onSuccessMsgToggle = { sub, active, amt, app, sName ->
                            viewModel.toggleSuccessMessageAction(sub, active, amt, app, sName)
                        },
                        onOtpErrorClick = viewModel::triggerOtpError,
                        onReloadClick = viewModel::triggerReload,
                        initialAmount = subAmount,
                        initialAppUsed = subApp
                    )
                }
            }
        }

        // Dialog Overlays
        if (showChangePinDialog) {
            ChangePinDialog(
                onDismiss = viewModel::closeChangePinDialog,
                onChangePinConfirm = viewModel::changePin
            )
        }
        if (showSupabaseConfigDialog) {
            SupabaseConfigDialog(
                currentUrl = viewModel.supabaseRepository.getSupabaseUrl(),
                currentKey = viewModel.supabaseRepository.getSupabaseKey(),
                currentTable = selectedTable,
                onDismiss = viewModel::closeSupabaseConfigDialog,
                onSaveConfig = viewModel::updateSupabaseConfig
            )
        }
    }
}
