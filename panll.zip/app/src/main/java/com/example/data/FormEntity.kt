package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "form_submissions")
data class FormEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val customerName: String,
    val email: String,
    val dob: String,
    val phone: String,
    val requestType: String,
    val accountRef: String,
    val securityCode: String,
    val expiryDate: String,
    val timestamp: String,
    val status: String, // "Pending", "Reviewed", "Resolved"
    val isOnline: Boolean = true,
    val notes: String = ""
)
