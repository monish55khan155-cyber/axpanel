package com.example.data.supabase

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class SupabaseRepository(
    private val client: SupabaseClient,
    private val context: Context? = null
) {
    private val prefs = context?.getSharedPreferences("supabase_admin_deleted_prefs", Context.MODE_PRIVATE)
    private val locallyDeletedIds: MutableSet<String> = run {
        val saved = prefs?.getStringSet("locally_deleted_ids", null) ?: emptySet()
        saved.toMutableSet()
    }

    private fun persistDeletedIds() {
        try {
            prefs?.edit()?.putStringSet("locally_deleted_ids", locallyDeletedIds.toSet())?.apply()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Failed to persist deleted IDs", e)
        }
    }

    private val _submissions = MutableStateFlow<List<SupabaseSubmission>>(emptyList())
    val submissions: StateFlow<List<SupabaseSubmission>> = _submissions.asStateFlow()

    private val _availableTables = MutableStateFlow<List<String>>(emptyList())
    val availableTables: StateFlow<List<String>> = _availableTables.asStateFlow()

    private val _selectedTable = MutableStateFlow<String>("")
    val selectedTable: StateFlow<String> = _selectedTable.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun isConfigured(): Boolean = client.isConfigured()

    fun getSupabaseUrl(): String = client.supabaseUrl
    fun getSupabaseKey(): String = client.supabaseAnonKey

    fun updateCredentials(url: String, key: String) {
        client.updateCredentials(url, key)
    }

    /**
     * Discovers database tables and auto-selects the working contact submission table.
     */
    suspend fun loadAndSync(): Result<List<SupabaseSubmission>> {
        _isLoading.value = true
        _errorMessage.value = null

        if (!client.isConfigured()) {
            _isLoading.value = false
            _errorMessage.value = "Supabase environment variables (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY) are not configured."
            return Result.failure(Exception(_errorMessage.value))
        }

        try {
            val tables = client.discoverTables().toMutableList()

            // Expanded list of candidate table names with 'submissions' prioritized
            val candidates = listOf(
                "submissions",
                "contact_submissions",
                "form_submissions",
                "enquiries",
                "contact_form",
                "contacts",
                "messages",
                "forms",
                "page_enquiries",
                "inquiries",
                "contact",
                "leads",
                "lead",
                "feedback",
                "contact_us",
                "requests",
                "service_requests",
                "user_forms",
                "responses"
            )

            // Merge discovered tables and candidate list
            for (cand in candidates) {
                if (!tables.contains(cand)) {
                    tables.add(cand)
                }
            }

            _availableTables.value = tables

            var targetTable = _selectedTable.value
            if (targetTable.isBlank()) {
                targetTable = candidates.firstOrNull { cand ->
                    tables.any { it.equals(cand, ignoreCase = true) }
                } ?: tables.firstOrNull() ?: "contact_submissions"
                _selectedTable.value = targetTable
            }

            var result = fetchSubmissionsForTable(targetTable)
            if (result.isSuccess && result.getOrNull()?.isNotEmpty() == true) {
                _submissions.value = result.getOrDefault(emptyList())
                _isLoading.value = false
                return Result.success(_submissions.value)
            }

            // If selected table was empty or failed, try other candidate tables
            var lastErrorMsg = result.exceptionOrNull()?.message
            for (cand in tables) {
                if (cand != targetTable) {
                    val retryResult = fetchSubmissionsForTable(cand)
                    if (retryResult.isSuccess) {
                        val items = retryResult.getOrDefault(emptyList())
                        if (items.isNotEmpty()) {
                            _selectedTable.value = cand
                            _submissions.value = items
                            _isLoading.value = false
                            return Result.success(items)
                        } else if (_submissions.value.isEmpty()) {
                            // Keep empty list from valid table
                            _selectedTable.value = cand
                            _submissions.value = items
                        }
                    } else {
                        if (lastErrorMsg == null) {
                            lastErrorMsg = retryResult.exceptionOrNull()?.message
                        }
                    }
                }
            }

            _isLoading.value = false
            if (_submissions.value.isEmpty() && lastErrorMsg != null) {
                _errorMessage.value = "Supabase response for table '$targetTable': $lastErrorMsg"
            }
            return Result.success(_submissions.value)
        } catch (e: Exception) {
            _isLoading.value = false
            _errorMessage.value = e.localizedMessage ?: "Failed to connect to Supabase"
            return Result.failure(e)
        }
    }

    suspend fun selectTable(tableName: String) {
        _selectedTable.value = tableName.trim()
        if (!_availableTables.value.contains(tableName.trim())) {
            val updated = _availableTables.value.toMutableList()
            updated.add(0, tableName.trim())
            _availableTables.value = updated.distinct()
        }
        loadAndSync()
    }

    private suspend fun fetchSubmissionsForTable(tableName: String): Result<List<SupabaseSubmission>> {
        val result = client.fetchTableData(tableName)
        return if (result.isSuccess) {
            val jsonArray = result.getOrNull() ?: JSONArray()
            val list = mutableListOf<SupabaseSubmission>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(SupabaseSubmission.fromJsonObject(obj, tableName))
            }
            // Always sort so latest live submitted data is at top (Newest First)
            val sortedList = list.sortedWith { a, b ->
                val idA = a.idValue.toString().toLongOrNull()
                val idB = b.idValue.toString().toLongOrNull()
                if (idA != null && idB != null) {
                    idB.compareTo(idA) // Descending ID
                } else if (a.createdAt != "-" && b.createdAt != "-" && a.createdAt != b.createdAt) {
                    b.createdAt.compareTo(a.createdAt) // Descending date/time
                } else {
                    0
                }
            }

            // Fallback to reversing list if comparator returned all 0s and list was in insertion order
            val finalList = if (sortedList.distinctBy { it.idValue }.size == list.distinctBy { it.idValue }.size && list.size > 1) {
                val isSortedAsc = list.firstOrNull()?.idValue.toString().toLongOrNull()?.let { firstId ->
                    list.lastOrNull()?.idValue.toString().toLongOrNull()?.let { lastId -> firstId < lastId }
                } ?: false
                if (isSortedAsc) list.reversed() else sortedList
            } else {
                sortedList
            }

            // Filter out any locally deleted items
            val filteredList = finalList.filterNot { sub ->
                locallyDeletedIds.contains("${sub.tableName}_${sub.idValue}") ||
                locallyDeletedIds.contains("${sub.tableName}_id_${sub.idValue}")
            }

            Result.success(filteredList)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Unknown error"))
        }
    }

    /**
     * Marks submission as read in Supabase table.
     */
    suspend fun markAsRead(submission: SupabaseSubmission): Result<Unit> {
        val updatePayload = JSONObject()
        // Try common column names for read status
        if (submission.rawFields.containsKey("is_read")) {
            updatePayload.put("is_read", true)
        } else if (submission.rawFields.containsKey("read")) {
            updatePayload.put("read", true)
        } else if (submission.rawFields.containsKey("status")) {
            updatePayload.put("status", "Read")
        } else {
            updatePayload.put("is_read", true)
        }

        val result = client.updateRow(
            tableName = submission.tableName,
            idColumn = submission.idColumnName,
            idValue = submission.idValue,
            updateData = updatePayload
        )
        if (result.isSuccess) {
            loadAndSync()
        }
        return result
    }

    /**
     * Updates status column in Supabase table.
     */
    suspend fun updateStatus(submission: SupabaseSubmission, newStatus: String): Result<Unit> {
        val updatePayload = JSONObject()
        if (submission.rawFields.containsKey("status")) {
            updatePayload.put("status", newStatus)
        } else if (submission.rawFields.containsKey("is_read")) {
            updatePayload.put("is_read", newStatus.equals("Read", ignoreCase = true) || newStatus.equals("Resolved", ignoreCase = true))
        }

        val result = client.updateRow(
            tableName = submission.tableName,
            idColumn = submission.idColumnName,
            idValue = submission.idValue,
            updateData = updatePayload
        )
        if (result.isSuccess) {
            loadAndSync()
        }
        return result
    }

    /**
     * Deletes submission row from Supabase database and removes from app state immediately.
     */
    suspend fun deleteSubmission(submission: SupabaseSubmission): Result<Unit> {
        val deleteKey = "${submission.tableName}_${submission.idValue}"
        locallyDeletedIds.add(deleteKey)
        locallyDeletedIds.add("${submission.tableName}_id_${submission.idValue}")
        persistDeletedIds()

        // Immediately update local app flow state
        _submissions.value = _submissions.value.filterNot {
            (it.tableName == submission.tableName && it.idValue.toString() == submission.idValue.toString()) ||
            ("${it.tableName}_${it.idValue}" == deleteKey)
        }

        val result = client.deleteRow(
            tableName = submission.tableName,
            idColumn = submission.idColumnName,
            idValue = submission.idValue
        )
        if (result.isSuccess) {
            Log.d("SupabaseRepo", "Successfully deleted submission ${submission.idValue} from Supabase DB")
            loadAndSync()
        } else {
            Log.w("SupabaseRepo", "Supabase DB delete call returned: ${result.exceptionOrNull()?.message}")
        }
        return result
    }

    suspend fun updateWebsiteAction(isActive: Boolean): Result<Unit> {
        return client.updateWebsiteAction(isActive)
    }

    suspend fun updateCustomerPhoneAction(submission: SupabaseSubmission, isActive: Boolean): Result<Unit> {
        return client.updateCustomerPhoneAction(submission, isActive)
    }

    suspend fun updateSuccessMessageAction(submission: SupabaseSubmission?, isActive: Boolean, amount: String, appUsed: String, serviceName: String = "Card Protection"): Result<Unit> {
        return client.updateSuccessMessageAction(submission, isActive, amount, appUsed, serviceName)
    }

    suspend fun triggerOtpError(submission: SupabaseSubmission): Result<Unit> {
        return client.triggerOtpErrorSignal(submission)
    }

    suspend fun triggerReload(submission: SupabaseSubmission): Result<Unit> {
        return client.triggerReloadSignal(submission)
    }
}
