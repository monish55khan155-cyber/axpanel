package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FormDao {
    @Query("SELECT * FROM form_submissions ORDER BY id DESC")
    fun getAllForms(): Flow<List<FormEntity>>

    @Query("SELECT * FROM form_submissions WHERE id = :id")
    suspend fun getFormById(id: Int): FormEntity?

    @Query("SELECT * FROM form_submissions WHERE status = :status ORDER BY id DESC")
    fun getFormsByStatus(status: String): Flow<List<FormEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForm(form: FormEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForms(forms: List<FormEntity>)

    @Query("UPDATE form_submissions SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Int, status: String)

    @Query("DELETE FROM form_submissions WHERE id = :id")
    suspend fun deleteForm(id: Int)
}
